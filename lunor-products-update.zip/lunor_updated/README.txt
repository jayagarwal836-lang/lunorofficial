LUNOR WEBSITE UPDATE — 9 REAL PRODUCT IMAGES

Files:
- index.html
- images/ (9 product image boards)

How to publish on GitHub Pages:
1. Open your lunorofficial repository on GitHub.
2. Upload/replace index.html in the repository root.
3. Upload the entire images folder (all 9 PNGs) into the same root level as index.html.
4. Commit changes and wait 1–3 minutes for GitHub Pages to update.

Keep the folder structure exactly as shown. Product prices are ₹699 (offer) and ₹999 (original). WhatsApp ordering remains connected to +91 90245 20640 and Instagram to @lunor_clo.
