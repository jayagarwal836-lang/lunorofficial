LUNOR WEBSITE — GitHub upload

1. Upload index.html to your GitHub repository.
2. Create a folder named "images".
3. Upload ALL 10 files from the images folder into that GitHub images folder.
4. Make sure the names stay exactly the same.
5. Commit the changes.
6. Your GitHub Pages site will update.

WhatsApp number already added:
+91 90245 20640

WhatsApp order message is generated automatically with product name and selected size.

Instagram:
https://instagram.com/lunor_clo

Prices:
Original ₹999
Offer ₹699
